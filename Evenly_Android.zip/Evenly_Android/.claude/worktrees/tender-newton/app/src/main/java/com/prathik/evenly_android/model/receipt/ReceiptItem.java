package com.prathik.evenly_android.model.receipt;

public class ReceiptItem {
}
