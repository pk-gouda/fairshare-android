package com.prathik.fairshare.ui.friends

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prathik.fairshare.domain.model.AccountStatus
import com.prathik.fairshare.domain.model.ApiResult
import com.prathik.fairshare.domain.model.Friend
import com.prathik.fairshare.domain.usecase.balance.GetAllBalancesUseCase
import com.prathik.fairshare.domain.usecase.friend.GetFriendsUseCase
import com.prathik.fairshare.data.local.PendingBalanceImpactEntity
import com.prathik.fairshare.data.sync.PendingOperationRepository
import com.prathik.fairshare.domain.repository.ExpenseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.prathik.fairshare.domain.model.BalanceCurrencyEntry

@HiltViewModel
class FriendsViewModel @Inject constructor(
    private val getFriendsUseCase         : GetFriendsUseCase,
    private val getAllBalancesUseCase      : GetAllBalancesUseCase,
    private val friendEventBus            : FriendEventBus,
    private val pendingOperationRepository: PendingOperationRepository,
    private val expenseRepository         : ExpenseRepository,
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // All friends — active, invited, placeholder — all from backend
    private val _friends = MutableStateFlow<List<Friend>>(emptyList())
    val friends: StateFlow<List<Friend>> = _friends.asStateFlow()

    // Map<friendId, List<Pair<amount, currency>>> — one entry per currency
    private val _balanceMap = MutableStateFlow<Map<String, List<Pair<Double, String>>>>(emptyMap())
    val balanceMap: StateFlow<Map<String, List<Pair<Double, String>>>> = _balanceMap.asStateFlow()

    // Multi-currency entries for the net balance bar
    private val _balanceEntries = MutableStateFlow<List<BalanceCurrencyEntry>>(emptyList())
    val balanceEntries: StateFlow<List<BalanceCurrencyEntry>> = _balanceEntries.asStateFlow()

    private val _owedToYou = MutableStateFlow(0.0)
    val owedToYou: StateFlow<Double> = _owedToYou.asStateFlow()

    private val _youOwe = MutableStateFlow(0.0)
    val youOwe: StateFlow<Double> = _youOwe.asStateFlow()

    /**
     * Global effective summary: confirmed ALL_BALANCES + all active pending deltas.
     * Null when no pending ops — fall back to confirmed owedToYou/youOwe/balanceEntries.
     * Uses the same formula as GroupsViewModel so both tabs show the same total.
     */
    private val _effectiveSummary = MutableStateFlow<com.prathik.fairshare.ui.groups.BalanceSummary?>(null)
    val effectiveSummary: StateFlow<com.prathik.fairshare.ui.groups.BalanceSummary?> =
        _effectiveSummary.asStateFlow()

    /** Per-friend optimistic balances — friendId → effective entries including pending delta. */
    private val _optimisticFriendBalanceMap =
        MutableStateFlow<Map<String, List<Pair<Double, String>>>>(emptyMap())
    val optimisticFriendBalanceMap: StateFlow<Map<String, List<Pair<Double, String>>>> =
        _optimisticFriendBalanceMap.asStateFlow()

    /** Friends that have at least one active pending expense op. */
    private val _friendsWithPendingSync = MutableStateFlow<Set<String>>(emptySet())
    val friendsWithPendingSync: StateFlow<Set<String>> = _friendsWithPendingSync.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _actionState = MutableStateFlow<FriendsActionState>(FriendsActionState.Idle)
    val actionState: StateFlow<FriendsActionState> = _actionState.asStateFlow()

    init {
        loadData()
        observeOptimisticFriendBalances()
        viewModelScope.launch {
            friendEventBus.friendAdded.collect { event ->
                _friends.value = event.updatedList
                val msg = if (event.addedCount == 1) "1 friend added" else "${event.addedCount} friends added"
                _actionState.value = FriendsActionState.Success(msg)
            }
        }
    }

    fun loadData() {
        viewModelScope.launch {
            if (_friends.value.isEmpty()) _isLoading.value = true

            // Friends first — instant from Room cache after first launch
            when (val result = getFriendsUseCase()) {
                is ApiResult.Success -> _friends.value = result.data
                else -> Unit
            }
            // Stop showing loader as soon as friends are ready
            _isLoading.value = false

            // Balances load independently — updates amounts when ready without blocking display
            launch {
                when (val result = getAllBalancesUseCase()) {
                    is ApiResult.Success -> {
                        val balances = result.data
                        // Per-friend: take the dominant currency (largest abs amount)
                        _balanceMap.value = balances
                            .groupBy { it.otherUserId }
                            .mapValues { (_, list) ->
                                // One Pair per currency — never sum across currencies
                                list.groupBy { it.currency }
                                    .map { (cur, entries) -> Pair(entries.sumOf { it.amount }, cur) }
                                    .filter { it.first != 0.0 }
                            }
                        // Per-currency entries for multi-currency net bar
                        val byCurrency = balances.groupBy { it.currency }
                        _balanceEntries.value = byCurrency.map { (currency, list) ->
                            val owedToMe = list.filter { it.amount > 0 }.sumOf { it.amount }
                            val youOwe   = list.filter { it.amount < 0 }.sumOf { -it.amount }
                            BalanceCurrencyEntry(currency, owedToMe, youOwe, owedToMe - youOwe)
                        }.filter { it.owedToMe > 0.0 || it.youOwe > 0.0 }
                        _owedToYou.value = balances.filter { it.amount > 0 }.sumOf { it.amount }
                        _youOwe.value    = balances.filter { it.amount < 0 }.sumOf { -it.amount }
                    }
                    else -> Unit
                }
            }
        }
    }

    fun onSearchChanged(query: String) { _searchQuery.value = query }

    // Active friends only — show in main list with balances
    fun filteredActiveFriends(): List<Friend> {
        val q = _searchQuery.value.trim().lowercase()
        return _friends.value
            .filter { it.isActive }
            .let { list ->
                if (q.isBlank()) list
                else list.filter {
                    it.fullName.lowercase().contains(q) ||
                            it.email.lowercase().contains(q)
                }
            }
    }

    // Invited + placeholder — shown separately with status badge
    fun filteredNonActiveFriends(): List<Friend> {
        val q = _searchQuery.value.trim().lowercase()
        return _friends.value
            .filter { it.isPlaceholder || it.isInvited }
            .let { list ->
                if (q.isBlank()) list
                else list.filter { it.fullName.lowercase().contains(q) }
            }
    }

    fun resetActionState() { _actionState.value = FriendsActionState.Idle }

    // ── Optimistic friend balance overlay ─────────────────────────────────────

    private fun observeOptimisticFriendBalances() {
        viewModelScope.launch {
            pendingOperationRepository.observeActivePendingExpenseOps().collect { ops ->
                if (ops.isEmpty()) {
                    _optimisticFriendBalanceMap.value = emptyMap()
                    _friendsWithPendingSync.value = emptySet()
                    _effectiveSummary.value = null  // revert to confirmed summary
                    return@collect
                }

                // Group ops by the friend they affect (otherUserId of the cached expense).
                // getCachedDirectOtherUserId returns null for group expenses — those are skipped.
                val opsByFriend = mutableMapOf<String, MutableList<com.prathik.fairshare.data.local.PendingOperationEntity>>()
                for (op in ops) {
                    val resourceId = op.localResourceId ?: op.serverResourceId ?: continue
                    val friendId = expenseRepository.getCachedDirectOtherUserId(resourceId) ?: continue
                    opsByFriend.getOrPut(friendId) { mutableListOf() }.add(op)
                }

                _friendsWithPendingSync.value = opsByFriend.keys.toSet()

                // Load UPDATE impacts once for all friends.
                val allImpacts: Map<String, PendingBalanceImpactEntity> =
                    pendingOperationRepository.getAllImpacts().associateBy { it.operationId }

                val result = mutableMapOf<String, List<Pair<Double, String>>>()
                for ((friendId, friendOps) in opsByFriend) {
                    // Confirmed base from ALL_BALANCES scope (what FriendsHome reads).
                    val confirmedEntries = _balanceMap.value[friendId]
                    val confirmedBase = confirmedEntries?.sumOf { it.first } ?: 0.0
                    val confirmedCurrency = confirmedEntries?.maxByOrNull { kotlin.math.abs(it.first) }?.second
                    val pendingCurrencies = if (confirmedCurrency == null) {
                        friendOps.mapNotNull { op ->
                            val id = op.localResourceId ?: op.serverResourceId ?: return@mapNotNull null
                            expenseRepository.getCachedExpense(id)?.currency
                        }.toSet()
                    } else emptySet()
                    val displayCurrency = confirmedCurrency
                        ?: pendingCurrencies.singleOrNull()
                        ?: continue

                    var delta = 0.0
                    for (op in friendOps) {
                        val resourceId = op.localResourceId ?: op.serverResourceId ?: continue
                        val expense = expenseRepository.getCachedExpense(resourceId) ?: continue
                        if (expense.currency != displayCurrency) continue
                        when (op.operationType) {
                            "CREATE_EXPENSE"  -> delta += expense.yourBalance
                            "DELETE_EXPENSE"  -> delta -= expense.yourBalance
                            "RESTORE_EXPENSE" -> delta += expense.yourBalance
                            "UPDATE_EXPENSE"  -> {
                                val impact = allImpacts[op.operationId]
                                if (impact != null) delta += impact.delta
                            }
                        }
                    }
                    result[friendId] = listOf(Pair(confirmedBase + delta, displayCurrency))
                }
                _optimisticFriendBalanceMap.value = result

                // Compute the SAME global effective summary as GroupsViewModel.
                // Both tabs must display the same top total.
                val confirmedSummary = buildConfirmedSummary()
                if (confirmedSummary != null) {
                    val allImpactsForSummary =
                        pendingOperationRepository.getAllImpacts().associateBy { it.operationId }
                    val deltasByCurrency = mutableMapOf<String, Double>()
                    for (op in ops) {
                        val resourceId = op.localResourceId ?: op.serverResourceId ?: continue
                        val expense    = expenseRepository.getCachedExpense(resourceId) ?: continue
                        val currency   = expense.currency
                        val d = when (op.operationType) {
                            "CREATE_EXPENSE"  -> expense.yourBalance
                            "DELETE_EXPENSE"  -> -expense.yourBalance
                            "RESTORE_EXPENSE" -> expense.yourBalance
                            "UPDATE_EXPENSE"  -> allImpactsForSummary[op.operationId]?.delta ?: 0.0
                            else              -> 0.0
                        }
                        deltasByCurrency[currency] = (deltasByCurrency[currency] ?: 0.0) + d
                    }
                    val newEntries = confirmedSummary.entries.map { entry ->
                        val delta  = deltasByCurrency[entry.currency] ?: 0.0
                        val newNet = entry.net + delta
                        val owed   = if (newNet > 0) newNet else 0.0
                        val owe    = if (newNet < 0) -newNet else 0.0
                        entry.copy(owedToMe = owed, youOwe = owe, net = newNet)
                    }
                    val existingCurrencies = confirmedSummary.entries.map { it.currency }.toSet()
                    val extraEntries = deltasByCurrency
                        .filterKeys { it !in existingCurrencies }
                        .map { (cur, d) ->
                            val owed = if (d > 0) d else 0.0
                            val owe  = if (d < 0) -d else 0.0
                            com.prathik.fairshare.domain.model.BalanceCurrencyEntry(cur, owed, owe, d)
                        }
                    val effEntries = (newEntries + extraEntries)
                        .filter { it.owedToMe > 0.0 || it.youOwe > 0.0 }
                    _effectiveSummary.value = com.prathik.fairshare.ui.groups.BalanceSummary(
                        owedToMe = effEntries.sumOf { it.owedToMe },
                        youOwe   = effEntries.sumOf { it.youOwe },
                        entries  = effEntries,
                    )
                }
            }
        }
    }

    /** Build a BalanceSummary from current confirmed balance data for effective-summary delta. */
    private fun buildConfirmedSummary(): com.prathik.fairshare.ui.groups.BalanceSummary? {
        val entries = _balanceEntries.value
        if (entries.isEmpty()) return null
        return com.prathik.fairshare.ui.groups.BalanceSummary(
            owedToMe = _owedToYou.value,
            youOwe   = _youOwe.value,
            entries  = entries,
        )
    }
}

sealed class FriendsActionState {
    object Idle : FriendsActionState()
    data class Success(val message: String) : FriendsActionState()
    data class Error(val message: String)   : FriendsActionState()
}