package com.prathik.fairshare.ui.settlement

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prathik.fairshare.data.local.EncryptedTokenStore
import com.prathik.fairshare.data.local.PendingBalanceImpactEntity
import com.prathik.fairshare.data.local.toEntity
import com.prathik.fairshare.data.sync.OperationType
import com.prathik.fairshare.data.sync.PendingOperationRepository
import android.content.Context
import com.prathik.fairshare.data.sync.SyncWorker
import com.prathik.fairshare.data.model.response.SettlementChangeLogResponse
import com.prathik.fairshare.data.network.api.SettlementApiService
import com.prathik.fairshare.data.network.safeApiCall
import com.prathik.fairshare.domain.model.ApiResult
import com.prathik.fairshare.domain.model.Settlement
import com.prathik.fairshare.domain.repository.SettlementRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettlementDetailViewModel @Inject constructor(
    private val settlementRepository      : SettlementRepository,
    private val settlementApiService      : SettlementApiService,
    private val tokenStore                : EncryptedTokenStore,
    private val pendingOperationRepository: PendingOperationRepository,
    @dagger.hilt.android.qualifiers.ApplicationContext private val appContext: android.content.Context,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    val settlementId: String = checkNotNull(savedStateHandle["settlementId"])
    val currentUserId: String? = tokenStore.getUserId()

    private val _state = MutableStateFlow<SettlementDetailUiState>(SettlementDetailUiState.Loading)
    val state: StateFlow<SettlementDetailUiState> = _state.asStateFlow()

    private val _actionState = MutableStateFlow<SettlementDetailActionState>(SettlementDetailActionState.Idle)
    val actionState: StateFlow<SettlementDetailActionState> = _actionState.asStateFlow()

    private val _changeLog = MutableStateFlow<List<SettlementChangeLogResponse>>(emptyList())
    val changeLog: StateFlow<List<SettlementChangeLogResponse>> = _changeLog.asStateFlow()

    private val _hasPendingSync = MutableStateFlow(false)
    val hasPendingSync: StateFlow<Boolean> = _hasPendingSync.asStateFlow()

    private var hasLoadedOnce = false

    init { load() }

    fun load() {
        viewModelScope.launch {
            if (!hasLoadedOnce) _state.value = SettlementDetailUiState.Loading
            when (val result = settlementRepository.getSettlementById(settlementId)) {
                is ApiResult.Success -> {
                    _state.value = SettlementDetailUiState.Success(result.data)
                    hasLoadedOnce = true
                    when (val logs = safeApiCall { settlementApiService.getSettlementChangelog(settlementId) }) {
                        is ApiResult.Success -> _changeLog.value = logs.data
                        else -> Unit
                    }
                }
                is ApiResult.NotFound -> _state.value = SettlementDetailUiState.NotFound
                is ApiResult.NetworkError -> {
                    if (!hasLoadedOnce) _state.value = SettlementDetailUiState.Error("No internet connection.")
                }
                else -> {
                    if (!hasLoadedOnce) _state.value = SettlementDetailUiState.Error("Failed to load settlement.")
                }
            }
        }
    }

    /**
     * Soft-cancels a COMPLETED settlement via DELETE endpoint.
     * Backend now returns 200 with CANCELLED status instead of deleting.
     * Screen reloads to show CANCELLED state with Restore option.
     */
    fun cancelSettlement() {
        viewModelScope.launch {
            if (hasDuplicatePending("CANCEL_SETTLEMENT")) return@launch
            _actionState.value = SettlementDetailActionState.Loading
            val currentSettlement = (_state.value as? SettlementDetailUiState.Success)?.settlement
            // Guard: do not cancel if already cancelled.
            if (currentSettlement?.status == com.prathik.fairshare.domain.model.SettlementStatus.CANCELLED) {
                _actionState.value = SettlementDetailActionState.Error("Settlement is already cancelled.")
                return@launch
            }
            when (val result = settlementRepository.cancelSettlement(settlementId)) {
                is ApiResult.Success -> {
                    _hasPendingSync.value = false
                    _actionState.value = SettlementDetailActionState.Cancelled
                }
                is ApiResult.NetworkError -> {
                    // Offline path: enqueue and optimistically update Room.
                    if (currentSettlement != null) {
                        applyOptimisticSettlementMutation(
                            settlement  = currentSettlement,
                            opType      = OperationType.CANCEL_SETTLEMENT,
                            endpoint    = "api/settlements/$settlementId/cancel",
                            method      = "POST",
                            newStatus   = com.prathik.fairshare.domain.model.SettlementStatus.CANCELLED,
                        )
                        _actionState.value = SettlementDetailActionState.SavedOffline
                    } else {
                        _actionState.value = SettlementDetailActionState.Error("No internet connection.")
                    }
                }
                is ApiResult.Forbidden -> _actionState.value =
                    SettlementDetailActionState.Error("You don't have permission to cancel this settlement.")
                else -> _actionState.value =
                    SettlementDetailActionState.Error("Failed to cancel settlement.")
            }
        }
    }

    /**
     * Restores a CANCELLED settlement to COMPLETED.
     * Re-applies existing allocation rows — no new rows created.
     * Screen reloads to show COMPLETED state.
     */
    fun restoreSettlement() {
        viewModelScope.launch {
            if (hasDuplicatePending("RESTORE_SETTLEMENT")) return@launch
            _actionState.value = SettlementDetailActionState.Loading
            val currentSettlement = (_state.value as? SettlementDetailUiState.Success)?.settlement
            // Guard: do not restore if already completed.
            if (currentSettlement?.status == com.prathik.fairshare.domain.model.SettlementStatus.COMPLETED) {
                _actionState.value = SettlementDetailActionState.Error("Settlement is already active.")
                return@launch
            }
            when (val result = settlementRepository.restoreSettlement(settlementId)) {
                is ApiResult.Success -> {
                    _hasPendingSync.value = false
                    _actionState.value = SettlementDetailActionState.Restored
                }
                is ApiResult.NetworkError -> {
                    if (currentSettlement != null) {
                        applyOptimisticSettlementMutation(
                            settlement  = currentSettlement,
                            opType      = OperationType.RESTORE_SETTLEMENT,
                            endpoint    = "api/settlements/$settlementId/restore",
                            method      = "POST",
                            newStatus   = com.prathik.fairshare.domain.model.SettlementStatus.COMPLETED,
                        )
                        _actionState.value = SettlementDetailActionState.SavedOffline
                    } else {
                        _actionState.value = SettlementDetailActionState.Error("No internet connection.")
                    }
                }
                is ApiResult.Forbidden -> _actionState.value =
                    SettlementDetailActionState.Error("You don't have permission to restore this settlement.")
                is ApiResult.Conflict -> _actionState.value =
                    SettlementDetailActionState.Error("Settlement is already active.")
                else -> _actionState.value =
                    SettlementDetailActionState.Error("Failed to restore settlement.")
            }
        }
    }

    /**
     * Permanently deletes this settlement (hard delete, not soft-cancel).
     * Backend DELETE endpoint is currently an alias for cancel — this is intentional.
     * Offline: enqueues DELETE_SETTLEMENT op with its own idempotency key.
     */
    fun deleteSettlement() {
        viewModelScope.launch {
            if (hasDuplicatePending("DELETE_SETTLEMENT")) return@launch
            _actionState.value = SettlementDetailActionState.Loading
            val currentSettlement = (_state.value as? SettlementDetailUiState.Success)?.settlement
            when (settlementRepository.deleteSettlement(settlementId)) {
                is ApiResult.Success -> {
                    _hasPendingSync.value = false
                    _actionState.value = SettlementDetailActionState.Deleted
                }
                is ApiResult.NetworkError -> {
                    if (currentSettlement != null) {
                        applyOptimisticSettlementMutation(
                            settlement = currentSettlement,
                            opType     = OperationType.DELETE_SETTLEMENT,
                            endpoint   = "api/settlements/$settlementId",
                            method     = "DELETE",
                            newStatus  = com.prathik.fairshare.domain.model.SettlementStatus.CANCELLED,
                        )
                        _actionState.value = SettlementDetailActionState.SavedOffline
                    } else {
                        _actionState.value = SettlementDetailActionState.Error("No internet connection.")
                    }
                }
                else -> _actionState.value = SettlementDetailActionState.Error("Failed to delete settlement.")
            }
        }
    }

    /**
     * Optimistically update Room + enqueue pending op + write balance impact.
     * Delta rule:
     *   cancel/delete  → reverse the settlement (if current user is payer: +amount back; receiver: -amount back)
     *   restore        → reapply the settlement
     */
    /**
     * Returns true if there is already an active pending op of the given type
     * for this settlement — prevents double-cancel / double-restore offline.
     */
    /**
     * Returns true if there is ANY active pending settlement op for this settlementId,
     * regardless of type. Prevents cancel→restore or cancel→delete before sync completes.
     */
    private suspend fun hasDuplicatePending(@Suppress("UNUSED_PARAMETER") opType: String): Boolean {
        val active = pendingOperationRepository.observeActivePendingSettlementOps()
            .first()
        return active.any {
            it.serverResourceId == settlementId || it.localResourceId == settlementId
        }
    }

    private suspend fun applyOptimisticSettlementMutation(
        settlement: com.prathik.fairshare.domain.model.Settlement,
        opType    : OperationType,
        endpoint  : String,
        method    : String,
        newStatus : com.prathik.fairshare.domain.model.SettlementStatus,
    ) {
        val userId = currentUserId ?: return
        // 1. Enqueue pending operation.
        val enqueued = pendingOperationRepository.enqueue(
            userId         = userId,
            operationType  = opType,
            endpoint       = endpoint,
            method         = method,
            requestBodyJson = null,
            serverResourceId = settlementId,
        )
        // 2. Optimistically update SettlementEntity status in Room.
        val updatedEntity = settlement.toEntity().copy(status = newStatus.name)
        // (SettlementRepositoryImpl.insertAll upserts by id)
        settlementRepository.upsertCachedSettlement(updatedEntity)
        // 3. Compute balance delta.
        //
        //    Balance convention (matches BalanceEntity.amount and FriendsScreen display):
        //      positive = other person owes me
        //      negative = I owe other person
        //
        //    A COMPLETED settlement by the payer pays off the payer's debt:
        //      - If I am the payer: my debt to friend decreases → balance moves toward 0
        //        i.e. completed settlement delta = +amount (debt paid off)
        //      - If I am the receiver: friend paid me, reducing what they owe me
        //        i.e. completed settlement delta = -amount (credit consumed)
        //
        //    CANCEL/DELETE reverses that completed effect:
        //      - I am the payer:   delta = -amount  (debt comes back)
        //      - I am the receiver: delta = +amount  (credit comes back)
        //
        //    RESTORE reapplies the completed effect (same sign as completed):
        //      - I am the payer:   delta = +amount
        //      - I am the receiver: delta = -amount
        val signedDelta = when (opType) {
            OperationType.CANCEL_SETTLEMENT, OperationType.DELETE_SETTLEMENT -> {
                if (settlement.payerId == userId) -settlement.amount else +settlement.amount
            }
            OperationType.RESTORE_SETTLEMENT -> {
                if (settlement.payerId == userId) +settlement.amount else -settlement.amount
            }
            else -> 0.0
        }
        val otherUserId = if (settlement.payerId == userId) settlement.receiverId else settlement.payerId
        if (signedDelta != 0.0) {
            val impact = PendingBalanceImpactEntity(
                operationId    = enqueued.operationId,
                expenseId      = "",  // not an expense — settlementId used instead
                groupId        = settlement.groupId,
                otherUserId    = otherUserId,
                currency       = settlement.currency,
                oldYourBalance = 0.0,
                newYourBalance = signedDelta,
                settlementId   = settlementId,
            )
            pendingOperationRepository.saveBalanceImpact(impact)
        }
        _hasPendingSync.value = true
        // 4. Update UI state to show new status optimistically.
        _state.value = SettlementDetailUiState.Success(settlement.copy(status = newStatus))
        // 5. Schedule sync for when connectivity returns.
        SyncWorker.triggerImmediateSync(appContext)
    }

    fun resetActionState() { _actionState.value = SettlementDetailActionState.Idle }

    /** True if current user is involved (payer, receiver, or recorder). */
    fun isParticipant(settlement: Settlement) =
        settlement.recordedById == currentUserId ||
                settlement.payerId == currentUserId ||
                settlement.receiverId == currentUserId
}

sealed class SettlementDetailUiState {
    object Loading  : SettlementDetailUiState()
    object NotFound : SettlementDetailUiState()
    /** @deprecated kept for backward compat — use NotFound */
    object Deleted  : SettlementDetailUiState()
    data class Success(val settlement: Settlement) : SettlementDetailUiState()
    data class Error(val message: String) : SettlementDetailUiState()
}

sealed class SettlementDetailActionState {
    object Idle      : SettlementDetailActionState()
    object Loading   : SettlementDetailActionState()
    /** Settlement was soft-cancelled — reload screen to show CANCELLED state. */
    object Cancelled : SettlementDetailActionState()
    /** Settlement was restored to COMPLETED — reload screen. */
    object Restored  : SettlementDetailActionState()
    data class Error(val message: String) : SettlementDetailActionState()
    /** Mutation saved locally while offline — pending sync. */
    object SavedOffline : SettlementDetailActionState()
    /** Settlement was permanently deleted. */
    object Deleted : SettlementDetailActionState()
}