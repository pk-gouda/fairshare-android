package com.prathik.fairshare.data.sync

import android.content.Context
import com.prathik.fairshare.data.local.toEntity
import com.prathik.fairshare.data.model.mapper.toDomain
import androidx.hilt.work.HiltWorker
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.prathik.fairshare.data.model.request.CreateExpenseRequest
import com.prathik.fairshare.data.model.request.UpdateExpenseRequest
import com.prathik.fairshare.domain.repository.ExpenseRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.serialization.json.Json
import java.util.concurrent.TimeUnit

/**
 * WorkManager worker that drains the pending operation queue.
 *
 * Runs only when network is available. On each pass it loads all PENDING
 * and FAILED_RETRYABLE operations (respecting dependency order) and attempts
 * to sync each one to the backend.
 *
 * Wave 2D-4: CREATE_EXPENSE operations are fully wired. The worker
 * deserialises the stored [CreateExpenseRequest] JSON and calls the expense
 * repository using the stable [PendingOperationEntity.idempotencyKey] so the
 * backend deduplicates any duplicate submissions automatically.
 *
 * UPDATE_EXPENSE / DELETE_EXPENSE / RESTORE_EXPENSE operations are enqueued
 * and marked SYNCED inline by their ViewModels while online; the stubs here
 * handle the case where the ViewModel failed and the queue contains a
 * FAILED_RETRYABLE row from a previous session. Full retry logic for those
 * types comes in Wave 2D-2 follow-up.
 *
 * Idempotency guarantee:
 * - Each operation carries a stable [PendingOperationEntity.idempotencyKey].
 * - The backend's idempotency_keys table deduplicates on this value.
 * - Re-running the worker after a crash cannot create duplicate financial records.
 */
@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val pendingOperationRepository: PendingOperationRepository,
    private val expenseRepository          : ExpenseRepository,
    private val mutationCacheRefresher     : ExpenseMutationCacheRefresher,
    private val json                       : Json,
    private val settlementApiService       : com.prathik.fairshare.data.network.api.SettlementApiService,
    private val settlementDao              : com.prathik.fairshare.data.local.SettlementDao,
    private val syncManager               : FairShareSyncManager,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val pending   = pendingOperationRepository.getPendingOperations()
        val retryable = pendingOperationRepository.getRetryableOperations()
        val allWork   = pending + retryable

        if (allWork.isEmpty()) return Result.success()

        var anyRetryableFailure = false

        for (operation in allWork) {
            val succeeded = syncOperation(
                operationId      = operation.operationId,
                operationType    = operation.operationType,
                idempotencyKey   = operation.idempotencyKey,
                requestBodyJson  = operation.requestBodyJson,
                endpoint         = operation.endpoint,
                localResourceId  = operation.localResourceId,
                operationUserId  = operation.userId,
            )
            if (!succeeded) anyRetryableFailure = true
        }

        // Clean up old SYNCED / CANCELLED rows on each pass (7-day TTL).
        pendingOperationRepository.cleanupCompleted()

        return if (anyRetryableFailure) Result.retry() else Result.success()
    }

    /**
     * Attempt to sync one pending operation to the backend.
     *
     * String primitives only — avoids KSP ordering issues where the
     * Hilt/AssistedInject processor runs before Room resolves entity types.
     *
     * @return true  → operation succeeded or permanently failed (no worker retry needed).
     *         false → retryable failure occurred; worker should schedule a retry.
     */
    private suspend fun syncOperation(
        operationId     : String,
        operationType   : String,
        idempotencyKey  : String,
        requestBodyJson : String?,
        endpoint        : String,
        localResourceId : String? = null,
        operationUserId : String  = "",
    ): Boolean {
        pendingOperationRepository.markSyncing(operationId)
        pendingOperationRepository.incrementRetry(operationId)

        return try {
            val type = try {
                OperationType.valueOf(operationType)
            } catch (e: IllegalArgumentException) {
                pendingOperationRepository.markFailed(
                    operationId, "Unknown operation type: $operationType"
                )
                return true // permanent — don't block the worker
            }

            when (type) {
                OperationType.CREATE_EXPENSE -> syncCreateExpense(
                    operationId     = operationId,
                    idempotencyKey  = idempotencyKey,
                    requestBodyJson = requestBodyJson,
                    localResourceId = localResourceId,
                    operationUserId = operationUserId,
                )

                OperationType.UPDATE_EXPENSE -> syncUpdateExpense(
                    operationId     = operationId,
                    idempotencyKey  = idempotencyKey,
                    requestBodyJson = requestBodyJson,
                    endpoint        = endpoint,
                    operationUserId = operationUserId,
                )

                OperationType.DELETE_EXPENSE -> syncDeleteExpense(
                    operationId     = operationId,
                    idempotencyKey  = idempotencyKey,
                    endpoint        = endpoint,
                    operationUserId = operationUserId,
                )

                OperationType.RESTORE_EXPENSE -> syncRestoreExpense(
                    operationId     = operationId,
                    idempotencyKey  = idempotencyKey,
                    endpoint        = endpoint,
                    operationUserId = operationUserId,
                )

                OperationType.CANCEL_SETTLEMENT -> syncCancelSettlement(
                    operationId = operationId, idempotencyKey = idempotencyKey,
                    endpoint = endpoint, operationUserId = operationUserId,
                )
                OperationType.RESTORE_SETTLEMENT -> syncRestoreSettlement(
                    operationId = operationId, idempotencyKey = idempotencyKey,
                    endpoint = endpoint, operationUserId = operationUserId,
                )
                OperationType.DELETE_SETTLEMENT -> syncDeleteSettlement(
                    operationId = operationId, idempotencyKey = idempotencyKey,
                    endpoint = endpoint, operationUserId = operationUserId,
                )
                OperationType.CREATE_SETTLEMENT,
                OperationType.UPDATE_SETTLEMENT -> {
                    pendingOperationRepository.markFailed(
                        operationId, "$operationType not yet implemented"
                    )
                    true
                }

                OperationType.ASSIGN_EXPENSE_ITEMS -> {
                    pendingOperationRepository.markFailed(
                        operationId, "Wave 2D not yet implemented for ASSIGN_EXPENSE_ITEMS"
                    )
                    true
                }
            }
        } catch (e: Exception) {
            val error = e.message ?: "Unknown error"
            pendingOperationRepository.markRetryable(operationId, error)
            false
        }
    }

    /**
     * Wave 2D-4: replay a CREATE_EXPENSE pending operation.
     *
     * Deserialises the stored [CreateExpenseRequest] JSON and calls the
     * repository with the original stable [idempotencyKey]. The backend's
     * idempotency_keys table guarantees exactly-once financial mutation even
     * if this runs multiple times.
     */
    private suspend fun syncCreateExpense(
        operationId     : String,
        idempotencyKey  : String,
        requestBodyJson : String?,
        localResourceId : String? = null,
        operationUserId : String = "",
    ): Boolean {
        if (requestBodyJson == null) {
            pendingOperationRepository.markFailed(
                operationId, "CREATE_EXPENSE pending operation has no requestBodyJson"
            )
            return true
        }

        val request = try {
            json.decodeFromString<CreateExpenseRequest>(requestBodyJson)
        } catch (e: Exception) {
            pendingOperationRepository.markFailed(
                operationId, "Failed to deserialise CREATE_EXPENSE body: ${e.message}"
            )
            return true
        }

        val result = expenseRepository.createExpense(
            groupId          = request.groupId,
            description      = request.description,
            totalAmount      = request.totalAmount,
            currency         = request.currency,
            splitType        = request.splitType,
            category         = request.category,
            notes            = request.notes,
            expenseDate      = request.expenseDate,
            payerData        = request.payerData,
            splitData        = request.splitData,
            receiptId        = request.receiptId,
            idempotencyKey   = idempotencyKey,   // stable key — never regenerated
            remainderPointer = request.remainderPointer,
            itemAssignments  = request.itemAssignments,
            repeatInterval   = request.repeatInterval,
        )

        return when (result) {
            is com.prathik.fairshare.domain.model.ApiResult.Success -> {
                pendingOperationRepository.markSynced(operationId, result.data.id)
                // Copy otherUserId from the placeholder to the server expense BEFORE
                // removing the placeholder. This keeps direct friend expenses visible
                // in Friend Detail offline without waiting for the next network refresh.
                localResourceId?.let {
                    expenseRepository.propagateOtherUserId(fromId = it, toId = result.data.id)
                }
                localResourceId?.let {
                    // Clean up placeholder payer/split rows before deleting the entity.
                    expenseRepository.deleteLocalPendingPayersAndSplits(it)
                    expenseRepository.deleteLocalExpense(it)
                }
                // Cascade cache refresh so FRIEND_NET/FRIEND_BREAKDOWN/GROUP_BALANCE
                // are current after offline-created expense syncs.
                val exp    = result.data
                val splits = request.splitData?.keys ?: emptySet()
                val payers = request.payerData?.keys ?: emptySet()
                mutationCacheRefresher.refreshAfterCreateSuccess(
                    expense       = exp,
                    groupId       = request.groupId,
                    currentUserId = operationUserId,
                    payerIds      = payers,
                    splitIds      = splits,
                )
                true
            }

            is com.prathik.fairshare.domain.model.ApiResult.NetworkError -> {
                pendingOperationRepository.markRetryable(
                    operationId, result.exception.message ?: "Network error"
                )
                false // signal worker to schedule a retry
            }

            // 409 Conflict — backend already processed this idempotency key with a
            // different body. Treat as permanent; user must recreate from scratch.
            is com.prathik.fairshare.domain.model.ApiResult.Conflict -> {
                pendingOperationRepository.markFailed(operationId, result.message)
                true
            }

            // 401 / 403 — permanent; user must re-authenticate or fix permissions.
            is com.prathik.fairshare.domain.model.ApiResult.Unauthorized,
            is com.prathik.fairshare.domain.model.ApiResult.Forbidden -> {
                pendingOperationRepository.markFailed(
                    operationId,
                    (result as? com.prathik.fairshare.domain.model.ApiResult.Forbidden)?.message
                        ?: "Unauthorized"
                )
                true
            }

            // 400 validation — permanent; stored body is malformed.
            is com.prathik.fairshare.domain.model.ApiResult.ValidationError -> {
                pendingOperationRepository.markFailed(operationId, result.message)
                true
            }

            // 5xx and other transient errors — keep retrying.
            else -> {
                pendingOperationRepository.markRetryable(operationId, "Server error, will retry")
                false
            }
        }
    }

    /**
     * Wave 2D-2: replay an UPDATE_EXPENSE pending operation.
     *
     * The expenseId is stored in [endpoint] as /api/expenses/{expenseId} and also
     * in [PendingOperationEntity.localResourceId]. We read it from the endpoint to
     * keep the function self-contained without needing the full entity.
     *
     * The same stable [idempotencyKey] is sent on every attempt so the backend's
     * idempotency_keys table prevents a double balance reversal/re-application.
     */
    private suspend fun syncUpdateExpense(
        operationId     : String,
        idempotencyKey  : String,
        requestBodyJson : String?,
        endpoint        : String,
        operationUserId : String = "",
    ): Boolean {
        if (requestBodyJson == null) {
            pendingOperationRepository.markFailed(
                operationId, "UPDATE_EXPENSE pending operation has no requestBodyJson"
            )
            return true
        }

        // Endpoint format: /api/expenses/{expenseId}
        val expenseId = endpoint.removePrefix("/api/expenses/").trim()
        if (expenseId.isBlank()) {
            pendingOperationRepository.markFailed(
                operationId, "Could not parse expenseId from endpoint: $endpoint"
            )
            return true
        }

        val request = try {
            json.decodeFromString<UpdateExpenseRequest>(requestBodyJson)
        } catch (e: Exception) {
            pendingOperationRepository.markFailed(
                operationId, "Failed to deserialise UPDATE_EXPENSE body: ${e.message}"
            )
            return true
        }

        // Read stored old participants from PendingBalanceImpactEntity (saved at offline-edit time
        // before Room was overwritten). Fall back to live Room context if not persisted.
        val storedImpact = pendingOperationRepository.getAllImpacts()
            .firstOrNull { it.operationId == operationId }
        val storedOldParticipants: Set<String> = storedImpact?.getOldParticipants() ?: emptySet()
        val oldContext = expenseRepository.getCachedExpenseMutationContext(expenseId)

        val result = expenseRepository.updateExpense(
            expenseId      = expenseId,
            description    = request.description,
            totalAmount    = request.totalAmount,
            currency       = request.currency,
            splitType      = request.splitType,
            category       = request.category,
            notes          = request.notes,
            expenseDate    = request.expenseDate,
            payerData      = request.payerData,
            splitData      = request.splitData,
            repeatInterval = request.repeatInterval,
            clearRepeat    = request.clearRepeat,
            idempotencyKey = idempotencyKey,   // stable key — never regenerated
        )

        return when (result) {
            is com.prathik.fairshare.domain.model.ApiResult.Success -> {
                // markSynced centrally deletes the impact row via PendingOperationRepository.
                pendingOperationRepository.markSynced(operationId, expenseId)
                // Resolve new participants: prefer server response (authoritative),
                // then request body, then cached old context (for metadata-only updates).
                val responseParticipants = ((result.data.payers?.map { it.userId } ?: emptyList()) +
                        (result.data.splits?.map { it.userId } ?: emptyList())).toSet()
                val requestParticipants = ((request.payerData?.keys ?: emptySet()) +
                        (request.splitData?.keys ?: emptySet()))
                val newParticipants = responseParticipants.ifEmpty {
                    requestParticipants.ifEmpty { oldContext?.participantIds ?: emptySet() }
                }
                mutationCacheRefresher.refreshAfterUpdateSuccess(
                    expense            = result.data,
                    groupId            = result.data.groupId,
                    currentUserId      = operationUserId,
                    oldParticipantIds  = storedOldParticipants.ifEmpty {
                        oldContext?.participantIds ?: emptySet()
                    },
                    newParticipantIds  = newParticipants,
                )
                true
            }

            is com.prathik.fairshare.domain.model.ApiResult.NetworkError -> {
                pendingOperationRepository.markRetryable(
                    operationId, result.exception.message ?: "Network error"
                )
                false // signal worker to retry
            }

            // 404 — expense was deleted while we were offline. Permanent.
            is com.prathik.fairshare.domain.model.ApiResult.NotFound -> {
                // markFailed centrally deletes the impact row.
                pendingOperationRepository.markFailed(operationId, "Expense no longer exists")
                true
            }

            // 403/401 — permission changed or session expired. Permanent.
            is com.prathik.fairshare.domain.model.ApiResult.Forbidden,
            is com.prathik.fairshare.domain.model.ApiResult.Unauthorized -> {
                pendingOperationRepository.markFailed(
                    operationId,
                    (result as? com.prathik.fairshare.domain.model.ApiResult.Forbidden)?.message
                        ?: "Unauthorized"
                )
                true
            }

            // 400 validation / 409 conflict — stored body is rejected. Permanent.
            is com.prathik.fairshare.domain.model.ApiResult.ValidationError -> {
                pendingOperationRepository.markFailed(operationId, result.message)
                true
            }

            is com.prathik.fairshare.domain.model.ApiResult.Conflict -> {
                pendingOperationRepository.markFailed(operationId, result.message)
                true
            }

            // 5xx and other transient errors — keep retrying.
            else -> {
                pendingOperationRepository.markRetryable(operationId, "Server error, will retry")
                false
            }
        }
    }

    /**
     * Wave 2D-3: replay a DELETE_EXPENSE pending operation.
     *
     * The expenseId is the last path segment of the endpoint: /api/expenses/{expenseId}.
     * The stable [idempotencyKey] is passed as the Idempotency-Key header so the backend
     * cannot reverse balances twice even if this runs multiple times.
     */
    private suspend fun syncDeleteExpense(
        operationId     : String,
        idempotencyKey  : String,
        endpoint        : String,
        operationUserId : String = "",
    ): Boolean {
        val expenseId = endpoint.removePrefix("/api/expenses/").trim()
        if (expenseId.isBlank()) {
            pendingOperationRepository.markFailed(
                operationId, "Could not parse expenseId from endpoint: $endpoint"
            )
            return true
        }

        // Capture participant context before delete — expense may be gone from server after.
        val deleteContext = expenseRepository.getCachedExpenseMutationContext(expenseId)

        val result = expenseRepository.deleteExpense(expenseId, idempotencyKey)

        return when (result) {
            is com.prathik.fairshare.domain.model.ApiResult.Success -> {
                pendingOperationRepository.markSynced(operationId, expenseId)
                mutationCacheRefresher.refreshAfterDeleteSuccess(
                    expenseId      = expenseId,
                    groupId        = deleteContext?.groupId,
                    currentUserId  = operationUserId,
                    participantIds = deleteContext?.participantIds ?: emptySet(),
                )
                true
            }
            is com.prathik.fairshare.domain.model.ApiResult.NetworkError -> {
                pendingOperationRepository.markRetryable(
                    operationId, result.exception.message ?: "Network error"
                )
                false
            }
            // 404 — already deleted. Still refresh caches so group/friend are consistent.
            is com.prathik.fairshare.domain.model.ApiResult.NotFound -> {
                pendingOperationRepository.markSynced(operationId, expenseId)
                mutationCacheRefresher.refreshAfterDeleteSuccess(
                    expenseId      = expenseId,
                    groupId        = deleteContext?.groupId,
                    currentUserId  = operationUserId,
                    participantIds = deleteContext?.participantIds ?: emptySet(),
                )
                true
            }
            is com.prathik.fairshare.domain.model.ApiResult.Forbidden,
            is com.prathik.fairshare.domain.model.ApiResult.Unauthorized,
            is com.prathik.fairshare.domain.model.ApiResult.ValidationError,
            is com.prathik.fairshare.domain.model.ApiResult.Conflict -> {
                val msg = when (result) {
                    is com.prathik.fairshare.domain.model.ApiResult.Forbidden -> result.message
                    is com.prathik.fairshare.domain.model.ApiResult.ValidationError -> result.message
                    is com.prathik.fairshare.domain.model.ApiResult.Conflict -> result.message
                    else -> "Unauthorized"
                }
                pendingOperationRepository.markFailed(operationId, msg)
                true
            }
            else -> {
                pendingOperationRepository.markRetryable(operationId, "Server error, will retry")
                false
            }
        }
    }

    /**
     * Wave 2D-3: replay a RESTORE_EXPENSE pending operation.
     *
     * Endpoint format: /api/expenses/{expenseId}/restore.
     * Same idempotency guarantee as delete — prevents a double balance re-application.
     */
    private suspend fun syncRestoreExpense(
        operationId     : String,
        idempotencyKey  : String,
        endpoint        : String,
        operationUserId : String = "",
    ): Boolean {
        // Strip prefix and suffix to isolate the expenseId
        val expenseId = endpoint
            .removePrefix("/api/expenses/")
            .removeSuffix("/restore")
            .trim()
        if (expenseId.isBlank()) {
            pendingOperationRepository.markFailed(
                operationId, "Could not parse expenseId from endpoint: $endpoint"
            )
            return true
        }

        // Capture context BEFORE restore call — the deleted expense's payer/split
        // rows are still in Room now. After backend restore, Room may update.
        val restoreContext = expenseRepository.getCachedExpenseMutationContext(expenseId)

        val result = expenseRepository.restoreExpense(expenseId, idempotencyKey)

        return when (result) {
            is com.prathik.fairshare.domain.model.ApiResult.Success -> {
                pendingOperationRepository.markSynced(operationId, expenseId)
                val restored = result.data
                // restoreContext was captured above, before the API call.
                val responseParticipants = ((restored.payers?.map { it.userId } ?: emptyList()) +
                        (restored.splits?.map { it.userId } ?: emptyList())).toSet()
                val participants = responseParticipants.ifEmpty {
                    restoreContext?.participantIds ?: emptySet()
                }
                mutationCacheRefresher.refreshAfterRestoreSuccess(
                    expense        = restored,
                    groupId        = restored.groupId,
                    currentUserId  = operationUserId,
                    participantIds = participants,
                )
                true
            }
            is com.prathik.fairshare.domain.model.ApiResult.NetworkError -> {
                pendingOperationRepository.markRetryable(
                    operationId, result.exception.message ?: "Network error"
                )
                false
            }
            is com.prathik.fairshare.domain.model.ApiResult.NotFound -> {
                // Expense doesn't exist — restore is meaningless. Mark permanent.
                pendingOperationRepository.markFailed(operationId, "Expense no longer exists")
                true
            }
            is com.prathik.fairshare.domain.model.ApiResult.Forbidden,
            is com.prathik.fairshare.domain.model.ApiResult.Unauthorized,
            is com.prathik.fairshare.domain.model.ApiResult.ValidationError,
            is com.prathik.fairshare.domain.model.ApiResult.Conflict -> {
                val msg = when (result) {
                    is com.prathik.fairshare.domain.model.ApiResult.Forbidden -> result.message
                    is com.prathik.fairshare.domain.model.ApiResult.ValidationError -> result.message
                    is com.prathik.fairshare.domain.model.ApiResult.Conflict -> result.message
                    else -> "Unauthorized"
                }
                pendingOperationRepository.markFailed(operationId, msg)
                true
            }
            else -> {
                pendingOperationRepository.markRetryable(operationId, "Server error, will retry")
                false
            }
        }
    }


    private suspend fun syncCancelSettlement(
        operationId    : String,
        idempotencyKey : String,
        endpoint       : String,
        operationUserId: String = "",
    ): Boolean = syncSettlementMutation(
        operationId = operationId, idempotencyKey = idempotencyKey,
        endpoint = endpoint, operationUserId = operationUserId,
        isDelete = false, apiCall = { id -> settlementApiService.cancelSettlement(id) },
    )

    private suspend fun syncRestoreSettlement(
        operationId    : String,
        idempotencyKey : String,
        endpoint       : String,
        operationUserId: String = "",
    ): Boolean = syncSettlementMutation(
        operationId = operationId, idempotencyKey = idempotencyKey,
        endpoint = endpoint, operationUserId = operationUserId,
        isDelete = false, apiCall = { id -> settlementApiService.restoreSettlement(id) },
    )

    private suspend fun syncDeleteSettlement(
        operationId    : String,
        idempotencyKey : String,
        endpoint       : String,
        operationUserId: String = "",
    ): Boolean = syncSettlementMutation(
        operationId = operationId, idempotencyKey = idempotencyKey,
        endpoint = endpoint, operationUserId = operationUserId,
        isDelete = true, apiCall = null,
    )

    private suspend fun syncSettlementMutation(
        operationId    : String,
        idempotencyKey : String,
        endpoint       : String,
        operationUserId: String,
        isDelete       : Boolean,
        apiCall        : (suspend (String) -> com.prathik.fairshare.data.model.response.ApiResponse<com.prathik.fairshare.data.model.response.SettlementResponse>)?,
    ): Boolean {
        // Parse settlementId: endpoint patterns are "api/settlements/{id}/cancel" or "api/settlements/{id}"
        val parts = endpoint.trimStart('/').split("/")
        val settlementId = parts.getOrNull(2) ?: parts.getOrNull(1) ?: run {
            pendingOperationRepository.markFailed(operationId, "Cannot parse settlementId from: $endpoint")
            return true
        }
        val cached = settlementDao.getById(settlementId)

        val rawResult = if (isDelete)
            com.prathik.fairshare.data.network.safeApiCall { settlementApiService.deleteSettlement(settlementId) }
        else
            com.prathik.fairshare.data.network.safeApiCall { apiCall!!(settlementId) }

        return when {
            rawResult is com.prathik.fairshare.domain.model.ApiResult.Success<*> -> {
                pendingOperationRepository.markSynced(operationId, settlementId)
                if (isDelete) {
                    settlementDao.deleteById(settlementId)
                } else {
                    @Suppress("UNCHECKED_CAST")
                    val resp = (rawResult as com.prathik.fairshare.domain.model.ApiResult.Success<com.prathik.fairshare.data.model.response.SettlementResponse>).data
                    settlementDao.insertAll(listOf(
                        resp.toDomain().toEntity()
                    ))
                }
                if (cached != null) {
                    syncManager.syncAfterSettlementMutation(
                        settlementId  = settlementId,
                        groupId       = cached.groupId,
                        payerId       = cached.payerId,
                        receiverId    = cached.receiverId,
                        currentUserId = operationUserId,
                        isDeleted     = isDelete,
                    )
                }
                true
            }
            rawResult is com.prathik.fairshare.domain.model.ApiResult.NetworkError -> {
                pendingOperationRepository.markRetryable(operationId, rawResult.exception.message ?: "Network error")
                false
            }
            rawResult is com.prathik.fairshare.domain.model.ApiResult.NotFound -> {
                settlementDao.deleteById(settlementId)
                pendingOperationRepository.markSynced(operationId, settlementId)
                true
            }
            rawResult is com.prathik.fairshare.domain.model.ApiResult.Conflict -> {
                pendingOperationRepository.markFailed(operationId, "Settlement state mismatch")
                true
            }
            else -> {
                pendingOperationRepository.markRetryable(operationId, "Server error, will retry")
                false
            }
        }
    }

    companion object {
        private const val PERIODIC_WORK_NAME   = "fairshare_sync_periodic"
        private const val ONETIME_WORK_NAME    = "fairshare_sync_onetime"
        private const val BACKOFF_DELAY_MILLIS = 30_000L // 30 seconds

        private val networkConstraint = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        /**
         * Schedule periodic background sync (every 15 minutes, network required).
         * Safe to call multiple times — uses [ExistingPeriodicWorkPolicy.KEEP].
         */
        fun schedulePeriodicSync(context: Context) {
            val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(networkConstraint)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    BACKOFF_DELAY_MILLIS,
                    TimeUnit.MILLISECONDS,
                )
                .build()

            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(
                    PERIODIC_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request,
                )
        }

        /**
         * Trigger an immediate one-shot sync (network required).
         * Call this after enqueueing a new pending operation to minimise latency.
         */
        fun triggerImmediateSync(context: Context) {
            val request = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(networkConstraint)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    BACKOFF_DELAY_MILLIS,
                    TimeUnit.MILLISECONDS,
                )
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork(
                    ONETIME_WORK_NAME,
                    androidx.work.ExistingWorkPolicy.KEEP,
                    request,
                )
        }
    }
}