package com.prathik.fairshare.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface BalanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(balances: List<BalanceEntity>)

    /** All rows for this user (any scope) — used for broad cache inspection. */
    @Query("SELECT * FROM balances WHERE userId = :userId")
    suspend fun getByUserId(userId: String): List<BalanceEntity>

    /** ALL_BALANCES scope only — safe for Friends tab / overall balance bar. */
    @Query("SELECT * FROM balances WHERE userId = :userId AND cacheScope = 'ALL_BALANCES'")
    suspend fun getAllBalanceRows(userId: String): List<BalanceEntity>

    /** FRIEND_NET scope for a specific friend — FriendDetail top balance. */
    @Query("SELECT * FROM balances WHERE userId = :userId AND otherUserId = :otherUserId AND cacheScope = 'FRIEND_NET'")
    suspend fun getFriendNetRows(userId: String, otherUserId: String): List<BalanceEntity>

    /** FRIEND_BREAKDOWN scope for a specific friend — FriendDetail group tiles. */
    @Query("SELECT * FROM balances WHERE userId = :userId AND otherUserId = :otherUserId AND cacheScope = 'FRIEND_BREAKDOWN'")
    suspend fun getFriendBreakdownRows(userId: String, otherUserId: String): List<BalanceEntity>

    /** GROUP_BALANCE scope for a specific group — GroupDetail balances. */
    @Query("SELECT * FROM balances WHERE userId = :userId AND groupId = :groupId AND cacheScope = 'GROUP_BALANCE'")
    suspend fun getGroupBalanceRows(userId: String, groupId: String): List<BalanceEntity>

    /** Cached net balance rows for a specific friend (non-group, groupId = ''). */
    @Query("SELECT * FROM balances WHERE userId = :userId AND otherUserId = :otherUserId AND groupId = ''")
    suspend fun getByOtherUserId(userId: String, otherUserId: String): List<BalanceEntity>

    /** Cached group balance rows for a specific group. */
    @Query("SELECT * FROM balances WHERE userId = :userId AND groupId = :groupId")
    suspend fun getByGroupId(userId: String, groupId: String): List<BalanceEntity>

    /** Delete GROUP_BALANCE scope rows for a specific group. */
    @Query("DELETE FROM balances WHERE userId = :userId AND groupId = :groupId AND cacheScope = 'GROUP_BALANCE'")
    suspend fun deleteByGroupId(userId: String, groupId: String)

    /** Delete FRIEND_NET scope rows for a specific friend. */
    @Query("DELETE FROM balances WHERE userId = :userId AND otherUserId = :otherUserId AND cacheScope = 'FRIEND_NET'")
    suspend fun deleteNetBalanceForFriend(userId: String, otherUserId: String)

    /** Delete FRIEND_BREAKDOWN scope rows for a specific friend. */
    @Query("DELETE FROM balances WHERE userId = :userId AND otherUserId = :otherUserId AND cacheScope = 'FRIEND_BREAKDOWN'")
    suspend fun deleteBreakdownForFriend(userId: String, otherUserId: String)

    @Query("DELETE FROM balances WHERE userId = :userId")
    suspend fun deleteByUserId(userId: String)

    @Query("DELETE FROM balances")
    suspend fun deleteAll()
}