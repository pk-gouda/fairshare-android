package com.prathik.fairshare.data.model.response

import com.prathik.fairshare.domain.model.SettlementStatus
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SettlementResponse(
    @SerialName("id")                val id: String,
    @SerialName("payerId")           val payerId: String,
    @SerialName("payerName")         val payerName: String,
    @SerialName("receiverId")        val receiverId: String,
    @SerialName("receiverName")      val receiverName: String,
    @SerialName("amount")            val amount: Double,
    @SerialName("currency")          val currency: String,
    @SerialName("groupId")           val groupId: String? = null,
    @SerialName("groupName")         val groupName: String? = null,
    @SerialName("status")            val status: SettlementStatus,
    @SerialName("notes")             val notes: String? = null,
    @SerialName("paymentMethod")     val paymentMethod: String? = null,
    @SerialName("paymentProofImage") val paymentProofImage: String? = null,
    @SerialName("recordedById")      val recordedById: String,
    @SerialName("recordedByName")    val recordedByName: String,
    @SerialName("settlementDate")    val settlementDate: String,
    @SerialName("completedAt")       val completedAt: String? = null,
    @SerialName("createdAt")         val createdAt: String,
)
