package com.prathik.fairshare.ui.groups

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prathik.fairshare.data.network.api.AnalyticsApiService
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import com.prathik.fairshare.data.network.safeApiCall
import com.prathik.fairshare.domain.model.ApiResult
import com.prathik.fairshare.ui.components.FsErrorScreen
import com.prathik.fairshare.ui.components.FsLoadingScreen
import com.prathik.fairshare.ui.components.FsTopBar
import com.prathik.fairshare.ui.theme.Green400
import com.prathik.fairshare.ui.theme.Radius
import com.prathik.fairshare.ui.theme.Spacing
import com.prathik.fairshare.ui.theme.Surface0
import com.prathik.fairshare.ui.theme.Surface2
import com.prathik.fairshare.ui.theme.Surface3
import com.prathik.fairshare.ui.theme.TextPrimary
import com.prathik.fairshare.ui.theme.TextSecondary
import com.prathik.fairshare.ui.theme.TextTertiary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── Shared analytics UI state ─────────────────────────────────────────────────

sealed class AnalyticsUiState {
    object Loading : AnalyticsUiState()
    data class Success(val data: JsonObject) : AnalyticsUiState()
    data class Error(val message: String) : AnalyticsUiState()
}

// ── GroupAnalyticsViewModel ───────────────────────────────────────────────────

@HiltViewModel
class GroupAnalyticsViewModel @Inject constructor(
    private val analyticsApiService: AnalyticsApiService,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    val groupId: String = checkNotNull(savedStateHandle["groupId"])

    private val _summaryState   = MutableStateFlow<AnalyticsUiState>(AnalyticsUiState.Loading)
    val summaryState: StateFlow<AnalyticsUiState> = _summaryState.asStateFlow()

    private val _categoryState  = MutableStateFlow<AnalyticsUiState>(AnalyticsUiState.Loading)
    val categoryState: StateFlow<AnalyticsUiState> = _categoryState.asStateFlow()

    private val _memberState    = MutableStateFlow<AnalyticsUiState>(AnalyticsUiState.Loading)
    val memberState: StateFlow<AnalyticsUiState> = _memberState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            val summaryDeferred  = async { safeApiCall { analyticsApiService.getGroupSummary(groupId) } }
            val categoryDeferred = async { safeApiCall { analyticsApiService.getGroupCategoryBreakdown(groupId) } }
            val memberDeferred   = async { safeApiCall { analyticsApiService.getGroupMemberBreakdown(groupId) } }

            _summaryState.value  = summaryDeferred.await().toUiState()
            _categoryState.value = categoryDeferred.await().toUiState()
            _memberState.value   = memberDeferred.await().toUiState()
        }
    }
}

// ── GroupAnalyticsScreen ──────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupAnalyticsScreen(
    onBack   : () -> Unit,
    viewModel: GroupAnalyticsViewModel = hiltViewModel(),
) {
    val summaryState  by viewModel.summaryState.collectAsState()
    val categoryState by viewModel.categoryState.collectAsState()
    val memberState   by viewModel.memberState.collectAsState()

    Scaffold(
        containerColor = Surface0,
        topBar         = { FsTopBar(title = "Group analytics", onBack = onBack) },
    ) { innerPadding ->
        if (summaryState is AnalyticsUiState.Loading) {
            FsLoadingScreen()
        } else if (summaryState is AnalyticsUiState.Error) {
            FsErrorScreen(
                message = (summaryState as AnalyticsUiState.Error).message,
                onRetry = { viewModel.load() }
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = Spacing.lg)
                    .verticalScroll(rememberScrollState()),
            ) {
                Spacer(Modifier.height(Spacing.md))

                // Summary card
                (summaryState as? AnalyticsUiState.Success)?.data?.let { data ->
                    AnalyticsSectionTitle("OVERVIEW")
                    Spacer(Modifier.height(Spacing.sm))
                    AnalyticsCard {
                        data.entries.sortedBy { it.key }.forEach { (key, value) ->
                            AnalyticsRow(label = key.toReadable(), value = value.jsonPrimitive.contentOrNull ?: value.toString().trim('"'))
                        }
                    }
                    Spacer(Modifier.height(Spacing.xl))
                }

                // Category breakdown
                (categoryState as? AnalyticsUiState.Success)?.data?.let { data ->
                    if (data.isNotEmpty()) {
                        AnalyticsSectionTitle("BY CATEGORY")
                        Spacer(Modifier.height(Spacing.sm))
                        AnalyticsCard {
                            data.entries.sortedByDescending {
                                it.value.jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: 0.0
                            }.forEach { (key, value) ->
                                AnalyticsRow(label = key.toReadable(), value = value.jsonPrimitive.contentOrNull ?: value.toString().trim('"'))
                            }
                        }
                        Spacer(Modifier.height(Spacing.xl))
                    }
                }

                // Member breakdown
                (memberState as? AnalyticsUiState.Success)?.data?.let { data ->
                    if (data.isNotEmpty()) {
                        AnalyticsSectionTitle("BY MEMBER")
                        Spacer(Modifier.height(Spacing.sm))
                        AnalyticsCard {
                            data.entries.sortedByDescending {
                                it.value.jsonPrimitive.contentOrNull?.toDoubleOrNull() ?: 0.0
                            }.forEach { (key, value) ->
                                AnalyticsRow(label = key.toReadable(), value = value.jsonPrimitive.contentOrNull ?: value.toString().trim('"'))
                            }
                        }
                    }
                }

                Spacer(Modifier.height(Spacing.xxxl))
            }
        }
    }
}

// ── MyAnalyticsViewModel ──────────────────────────────────────────────────────

@HiltViewModel
class MyAnalyticsViewModel @Inject constructor(
    private val analyticsApiService: AnalyticsApiService,
) : ViewModel() {

    private val _summaryState = MutableStateFlow<AnalyticsUiState>(AnalyticsUiState.Loading)
    val summaryState: StateFlow<AnalyticsUiState> = _summaryState.asStateFlow()

    private val _statsState   = MutableStateFlow<AnalyticsUiState>(AnalyticsUiState.Loading)
    val statsState: StateFlow<AnalyticsUiState> = _statsState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            val summaryDeferred = async { safeApiCall { analyticsApiService.getPersonalSummary() } }
            val statsDeferred   = async { safeApiCall { analyticsApiService.getPersonalStats() } }
            _summaryState.value = summaryDeferred.await().toUiState()
            _statsState.value   = statsDeferred.await().toUiState()
        }
    }
}

// ── MyAnalyticsScreen ─────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAnalyticsScreen(
    onBack   : () -> Unit,
    viewModel: MyAnalyticsViewModel = hiltViewModel(),
) {
    val summaryState by viewModel.summaryState.collectAsState()
    val statsState   by viewModel.statsState.collectAsState()

    Scaffold(
        containerColor = Surface0,
        topBar         = { FsTopBar(title = "My analytics", onBack = onBack) },
    ) { innerPadding ->
        if (summaryState is AnalyticsUiState.Loading) {
            FsLoadingScreen()
        } else if (summaryState is AnalyticsUiState.Error) {
            FsErrorScreen(
                message = (summaryState as AnalyticsUiState.Error).message,
                onRetry = { viewModel.load() }
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = Spacing.lg)
                    .verticalScroll(rememberScrollState()),
            ) {
                Spacer(Modifier.height(Spacing.md))

                (summaryState as? AnalyticsUiState.Success)?.data?.let { data ->
                    AnalyticsSectionTitle("SPENDING SUMMARY")
                    Spacer(Modifier.height(Spacing.sm))
                    AnalyticsCard {
                        data.entries.sortedBy { it.key }.forEach { (key, value) ->
                            AnalyticsRow(label = key.toReadable(), value = value.jsonPrimitive.contentOrNull ?: value.toString().trim('"'))
                        }
                    }
                    Spacer(Modifier.height(Spacing.xl))
                }

                (statsState as? AnalyticsUiState.Success)?.data?.let { data ->
                    AnalyticsSectionTitle("STATS")
                    Spacer(Modifier.height(Spacing.sm))
                    AnalyticsCard {
                        data.entries.sortedBy { it.key }.forEach { (key, value) ->
                            AnalyticsRow(label = key.toReadable(), value = value.jsonPrimitive.contentOrNull ?: value.toString().trim('"'))
                        }
                    }
                }

                Spacer(Modifier.height(Spacing.xxxl))
            }
        }
    }
}

// ── FriendAnalyticsViewModel ──────────────────────────────────────────────────

@HiltViewModel
class FriendAnalyticsViewModel @Inject constructor(
    private val analyticsApiService: AnalyticsApiService,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    val friendId: String = checkNotNull(savedStateHandle["friendId"])

    private val _trendsState = MutableStateFlow<AnalyticsUiState>(AnalyticsUiState.Loading)
    val trendsState: StateFlow<AnalyticsUiState> = _trendsState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _trendsState.value = safeApiCall {
                analyticsApiService.getFriendTrends(friendId)
            }.toUiState()
        }
    }
}

// ── FriendAnalyticsScreen ─────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendAnalyticsScreen(
    onBack   : () -> Unit,
    viewModel: FriendAnalyticsViewModel = hiltViewModel(),
) {
    val trendsState by viewModel.trendsState.collectAsState()

    Scaffold(
        containerColor = Surface0,
        topBar         = { FsTopBar(title = "Spending trends", onBack = onBack) },
    ) { innerPadding ->
        when (val s = trendsState) {
            is AnalyticsUiState.Loading -> FsLoadingScreen()
            is AnalyticsUiState.Error   -> FsErrorScreen(message = s.message, onRetry = { viewModel.load() })
            is AnalyticsUiState.Success -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = Spacing.lg)
                        .verticalScroll(rememberScrollState()),
                ) {
                    Spacer(Modifier.height(Spacing.md))
                    AnalyticsSectionTitle("MONTHLY TRENDS")
                    Spacer(Modifier.height(Spacing.sm))
                    AnalyticsCard {
                        s.data.toSortedMap().forEach { (key, value) ->
                            AnalyticsRow(label = key.toReadable(), value = value.toString())
                        }
                    }
                    Spacer(Modifier.height(Spacing.xxxl))
                }
            }
        }
    }
}

// ── Shared composables ────────────────────────────────────────────────────────

@Composable
private fun AnalyticsSectionTitle(text: String) {
    Text(
        text          = text,
        fontSize      = 11.sp,
        fontWeight    = FontWeight.SemiBold,
        color         = TextTertiary,
        letterSpacing = 0.8.sp,
    )
}

@Composable
private fun AnalyticsCard(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Radius.xl))
            .background(Surface2),
    ) {
        content()
    }
}

@Composable
private fun AnalyticsRow(label: String, value: String) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .padding(horizontal = Spacing.md, vertical = Spacing.md),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = label, fontSize = 14.sp, color = TextSecondary, modifier = Modifier.weight(1f))
        Text(text = value, fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
    }
    HorizontalDivider(color = Surface3, thickness = 0.5.dp, modifier = Modifier.padding(start = Spacing.md))
}

// ── Helpers ───────────────────────────────────────────────────────────────────

private fun ApiResult<JsonObject>.toUiState(): AnalyticsUiState = when (this) {
    is ApiResult.Success      -> AnalyticsUiState.Success(data)
    is ApiResult.NetworkError -> AnalyticsUiState.Error("No internet connection.")
    else                      -> AnalyticsUiState.Error("Failed to load analytics.")
}

/** Converts camelCase/snake_case API keys to readable labels. */
private fun String.toReadable(): String =
    replace('_', ' ')
        .replace(Regex("([A-Z])")) { " ${it.value}" }
        .trim()
        .replaceFirstChar { it.uppercase() }